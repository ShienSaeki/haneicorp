
// shared-navbar.js

document.write(`
<header>
  <img src="HANEI.jpg" alt="HANEI Logo" style="height: 40px; vertical-align: middle;">
  <nav style="display: inline-block; margin-left: 30px;">
    <a href="index.html">Home</a>
    <a href="about.html">About</a>
    <a href="hanei_voc_systems.html">Products</a>
    <a href="hanei_technical_support.html">Support</a>
    <a href="hanei_brand_partners.html">Brands</a>
    <a href="contact.html">Contact</a>
  </nav>
</header>
`);

document.write(`
<footer style="background: #222; color: white; text-align: center; padding: 20px; font-size: 14px;">
  © 2025 HANEI Corporation. | Osaka, Japan | TEL: 06-7713-5321
</footer>
`);
